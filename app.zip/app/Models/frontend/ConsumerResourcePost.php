<?php

namespace App\Models\frontend;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
// use App\Models\frontend\Resource;

class ConsumerResourcePost extends Model
{
    // public function resource()
    // {
    //     return $this->belongsTo(Resource::class, 'resource_type');
    // }
}
